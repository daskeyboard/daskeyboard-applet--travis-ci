# Travis Build Info

Get Travis build status alerts directly on a Das Keyboard Q keyboard. Requires a Travis account and the token linked to this account.


## Example

State of one key when a build is failing
![Travis on a Das Keybaord Q](assets/image.png "Travis")
