# Changelog Q Applet Travis Build Info


#### 1.0.0 (2018-12-31)

First release

